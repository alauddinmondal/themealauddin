<div class="spcFootercopyright">
<footer>
<div class="container">
<div class="row">
<div class="col-md-12">
footer
</div>
</div>
</div>

</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>